# Pi Bitwise + J-LO Starter Pack (v1)

This pack gives you two small programs for a Raspberry Pi (64‑bit OS):
1. **bitwise_div** — your universal bitwise divider (no FP), with a baseline check.
2. **jlo_hybrid** — a tiny "J‑LO" style scheduler: splits work into *small* vs *big*
   by divisor bit-length and runs them on separate OpenMP pools (simulates CPU/GPU split).

## Quick start (Raspberry Pi OS 64‑bit)

```bash
sudo apt update
sudo apt install -y build-essential clang

# Optional (for OpenMP threading)
sudo apt install -y libgomp1

# Build
make -j

# Run bitwise divider test (N=2,000,000 by default)
./bitwise_div 2000000

# Run J‑LO hybrid demo (N=10,000,000, THRESH=63 by default)
./jlo_hybrid 10000000 63
```

If your toolchain supports OpenMP, the programs will use multiple threads. Otherwise they run single-threaded.

## Files

- `src/bitwise_div.c` — portable C (uses `__int128` internally, supported by GCC/Clang on aarch64).
- `src/jlo_hybrid.c` — the "J‑LO" workload splitter with two thread regions.
- `Makefile` — builds both with GCC or Clang.
- `run.sh` — convenience build+run wrapper.
- `tools/governor.sh` — set CPU governor to `performance` (Pi 4/5).

## Notes

- No floating-point in the math path; uses fixed-point reciprocal + one Newton step + exact correction.
- Baseline verification compares against C `/` and `%` for correctness and prints mismatch counts.
- The J‑LO demo simulates the hybrid split by running *small* and *big* partitions concurrently
  using two OpenMP regions. On a Pi, there is no GPU compute here — it's a *fabric simulation* of the split logic.

## Security & reproducibility

- Run offline if you prefer. All code is in this folder — no network access required.
- For deterministic input streams you can fix the RNG seed in the code or via `XRNG_SEED` env var.
