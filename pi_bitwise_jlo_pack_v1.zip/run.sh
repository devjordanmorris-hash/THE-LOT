#!/usr/bin/env bash
set -euo pipefail
make -j
echo "---- bitwise_div (2,000,000) ----"
./bitwise_div 2000000
echo
echo "---- jlo_hybrid (10,000,000, THRESH=63) ----"
./jlo_hybrid 10000000 63
