// bitwise_div.c — Universal divide vs baseline (CPU-only, Pi-friendly)
#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
#include <time.h>
#include <stdlib.h>

#if defined(_OPENMP)
  #include <omp.h>
#else
  static int omp_get_max_threads(void){ return 1; }
  static void omp_set_num_threads(int n){ (void)n; }
  static int omp_get_num_threads(void){ return 1; }
  static int omp_get_thread_num(void){ return 0; }
#endif

static inline uint64_t xrng(void) {
    static uint64_t s = 0x9e3779b97f4a7c15ULL;
    s ^= s >> 12; s ^= s << 25; s ^= s >> 27;
    return s * 0x2545F4914F6CDD1DULL;
}
static inline double now_sec(void) {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}
static inline uint32_t bitlen_u64(uint64_t x){
    if (!x) return 0;
#if defined(__clang__) || defined(__GNUC__)
    return 64u - (uint32_t)__builtin_clzll(x);
#else
    uint32_t n=0; while (x){ n++; x >>= 1; } return n;
#endif
}

// Universal divide: fixed-point reciprocal + one Newton + exact correction
static inline void udiv_universal_u64(uint64_t x, uint64_t y, uint64_t *q_out, uint64_t *r_out){
    // Preconditions: y > 0
    uint32_t ybits = bitlen_u64(y);
    uint32_t S = ybits + 16u; if (S > 56u) S = 56u;

    __uint128_t oneS = ((__uint128_t)1) << S;
    __uint128_t r = oneS / y;

    __uint128_t yr = (((__uint128_t)y) * r) >> S;
    __uint128_t two = ((__uint128_t)2) << S;
    r = (r * (two - yr)) >> S;

    __uint128_t X = (((__uint128_t)x) * r);
    uint64_t q0 = (uint64_t)(X >> S);

    __int128 rem = (__int128)x - (__int128)q0 * (__int128)y;
    if (rem >= (__int128)y) { q0++; rem -= (__int128)y; }
    else if (rem < 0)       { q0--; rem += (__int128)y; }

    *q_out = q0;
    *r_out = (uint64_t)rem;
}

int main(int argc, char** argv){
    size_t N = 2000000;
    if (argc > 1){ size_t v = strtoull(argv[1], NULL, 10); if (v>=1000 && v<=1000000000ull) N=v; }
    uint64_t *xs = (uint64_t*)malloc(N*sizeof(uint64_t));
    uint64_t *ys = (uint64_t*)malloc(N*sizeof(uint64_t));
    for (size_t i=0;i<N;++i){
        xs[i] = xrng();
        uint64_t y; do { y = xrng(); } while (y == 0); ys[i] = y;
    }

    // Universal divide bench
    double t0 = now_sec();
    uint64_t sQ=0,sR=0;
    #pragma omp parallel
    {
        uint64_t lQ=0,lR=0;
        #pragma omp for schedule(static)
        for (size_t i=0;i<N;++i){
            uint64_t q,r; udiv_universal_u64(xs[i], ys[i], &q, &r);
            lQ ^= q; lR ^= r;
        }
        #pragma omp atomic
        sQ ^= lQ;
        #pragma omp atomic
        sR ^= lR;
    }
    double t1 = now_sec();

    // Baseline
    double t2 = now_sec();
    uint64_t sQb=0,sRb=0;
    #pragma omp parallel
    {
        uint64_t lQ=0,lR=0;
        #pragma omp for schedule(static)
        for (size_t i=0;i<N;++i){
            uint64_t q = xs[i]/ys[i];
            uint64_t r = xs[i]%ys[i];
            lQ ^= q; lR ^= r;
        }
        #pragma omp atomic
        sQb ^= lQ;
        #pragma omp atomic
        sRb ^= lR;
    }
    double t3 = now_sec();

    // Correctness sample
    size_t exact = 0;
    size_t checkN = (N < 500000 ? N : 500000);
    for (size_t i=0;i<checkN;++i){
        uint64_t q,r; udiv_universal_u64(xs[i], ys[i], &q, &r);
        uint64_t qb = xs[i]/ys[i], rb = xs[i]%ys[i];
        if (q==qb && r==rb) exact++;
    }

    double upc_ns = (t1-t0)*1e9 / (double)N;
    double bpc_ns = (t3-t2)*1e9 / (double)N;
    printf("Pi bitwise_div N=%zu\n", N);
    printf("Universal:  %.3f ms (%.2f ns/op)  sink=%" PRIu64 ",%" PRIu64 "\n", (t1-t0)*1e3, upc_ns, sQ, sR);
    printf("Baseline:   %.3f ms (%.2f ns/op)  sink=%" PRIu64 ",%" PRIu64 "\n", (t3-t2)*1e3, bpc_ns, sQb, sRb);
    printf("Correctness sample %zu:  %.2f%%\n", checkN, 100.0*(double)exact/(double)checkN);

    free(xs); free(ys);
    return 0;
}
