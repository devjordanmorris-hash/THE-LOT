// jlo_hybrid.c — Tiny "J‑LO" style splitter demo (CPU-only fabric simulation)
#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
#include <time.h>
#include <stdlib.h>

#if defined(_OPENMP)
  #include <omp.h>
#else
  static int omp_get_max_threads(void){ return 1; }
  static void omp_set_num_threads(int n){ (void)n; }
  static int omp_get_num_threads(void){ return 1; }
  static int omp_get_thread_num(void){ return 0; }
#endif

static inline uint64_t xrng(void) {
    static uint64_t s = 0x9e3779b97f4a7c15ULL;
    s ^= s >> 12; s ^= s << 25; s ^= s >> 27;
    return s * 0x2545F4914F6CDD1DULL;
}
static inline double now_sec(void) {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}
static inline uint32_t bitlen_u64(uint64_t x){
    if (!x) return 0;
#if defined(__clang__) || defined(__GNUC__)
    return 64u - (uint32_t)__builtin_clzll(x);
#else
    uint32_t n=0; while (x){ n++; x >>= 1; } return n;
#endif
}

// Universal divide core (as before)
static inline void udiv_universal_u64(uint64_t x, uint64_t y, uint64_t *q_out, uint64_t *r_out){
    uint32_t ybits = bitlen_u64(y);
    uint32_t S = ybits + 16u; if (S > 56u) S = 56u;
    __uint128_t oneS = ((__uint128_t)1) << S;
    __uint128_t r = oneS / y;
    __uint128_t yr = (((__uint128_t)y) * r) >> S;
    __uint128_t two = ((__uint128_t)2) << S;
    r = (r * (two - yr)) >> S;
    __uint128_t X = (((__uint128_t)x) * r);
    uint64_t q0 = (uint64_t)(X >> S);
    __int128 rem = (__int128)x - (__int128)q0 * (__int128)y;
    if (rem >= (__int128)y) { q0++; rem -= (__int128)y; }
    else if (rem < 0)       { q0--; rem += (__int128)y; }
    *q_out = q0; *r_out = (uint64_t)rem;
}

int main(int argc, char** argv){
    size_t N = 10000000;
    uint32_t THRESH = 63; // bitlen(y) <= THRESH -> "small" path
    if (argc > 1){ size_t v = strtoull(argv[1], NULL, 10); if (v>=1000) N=v; }
    if (argc > 2){ unsigned long t = strtoul(argv[2], NULL, 10); if (t>=8 && t<=63) THRESH=(uint32_t)t; }

    uint64_t *xs = (uint64_t*)malloc(N*sizeof(uint64_t));
    uint64_t *ys = (uint64_t*)malloc(N*sizeof(uint64_t));
    for (size_t i=0;i<N;++i){
        xs[i] = xrng();
        uint64_t y; do { y = xrng(); } while (y == 0); ys[i] = y;
    }

    // Partition by bit-length
    size_t smallN=0,bigN=0;
    for (size_t i=0;i<N;++i){ if (bitlen_u64(ys[i]) <= THRESH) smallN++; else bigN++; }

    uint64_t *xs_small = (uint64_t*)malloc(smallN*sizeof(uint64_t));
    uint64_t *ys_small = (uint64_t*)malloc(smallN*sizeof(uint64_t));
    uint32_t *idx_small = (uint32_t*)malloc(smallN*sizeof(uint32_t));
    uint64_t *xs_big = (uint64_t*)malloc(bigN*sizeof(uint64_t));
    uint64_t *ys_big = (uint64_t*)malloc(bigN*sizeof(uint64_t));
    uint32_t *idx_big = (uint32_t*)malloc(bigN*sizeof(uint32_t));

    size_t ps=0, pb=0;
    for (size_t i=0;i<N;++i){
        if (bitlen_u64(ys[i]) <= THRESH){ xs_small[ps]=xs[i]; ys_small[ps]=ys[i]; idx_small[ps]=(uint32_t)i; ps++; }
        else { xs_big[pb]=xs[i]; ys_big[pb]=ys[i]; idx_big[pb]=(uint32_t)i; pb++; }
    }

    uint64_t *q_out = (uint64_t*)malloc(N*sizeof(uint64_t));
    uint64_t *r_out = (uint64_t*)malloc(N*sizeof(uint64_t));

    // Simulate two engines: small-path and big-path, run concurrently (OpenMP sections)
    double t0 = now_sec();
    uint64_t sQ_small=0,sR_small=0,sQ_big=0,sR_big=0;

    #pragma omp parallel sections
    {
        #pragma omp section
        {
            #pragma omp parallel
            {
                uint64_t lQ=0,lR=0;
                #pragma omp for schedule(static)
                for (size_t i=0;i<smallN;++i){
                    uint64_t q,r; udiv_universal_u64(xs_small[i], ys_small[i], &q, &r);
                    q_out[idx_small[i]] = q; r_out[idx_small[i]] = r;
                    lQ ^= q; lR ^= r;
                }
                #pragma omp atomic
                sQ_small ^= lQ;
                #pragma omp atomic
                sR_small ^= lR;
            }
        }
        #pragma omp section
        {
            #pragma omp parallel
            {
                uint64_t lQ=0,lR=0;
                #pragma omp for schedule(static)
                for (size_t i=0;i<bigN;++i){
                    uint64_t q,r; udiv_universal_u64(xs_big[i], ys_big[i], &q, &r);
                    q_out[idx_big[i]] = q; r_out[idx_big[i]] = r;
                    lQ ^= q; lR ^= r;
                }
                #pragma omp atomic
                sQ_big ^= lQ;
                #pragma omp atomic
                sR_big ^= lR;
            }
        }
    }
    double t1 = now_sec();

    // Baseline single-path reference
    double t2 = now_sec();
    uint64_t sQb=0, sRb=0;
    #pragma omp parallel
    {
        uint64_t lQ=0,lR=0;
        #pragma omp for schedule(static)
        for (size_t i=0;i<N;++i){
            uint64_t q = xs[i]/ys[i];
            uint64_t r = xs[i]%ys[i];
            lQ ^= q; lR ^= r;
        }
        #pragma omp atomic
        sQb ^= lQ;
        #pragma omp atomic
        sRb ^= lR;
    }
    double t3 = now_sec();

    // Validate
    size_t mism=0;
    #pragma omp parallel for reduction(+:mism) schedule(static)
    for (size_t i=0;i<N;++i){
        uint64_t qb = xs[i]/ys[i], rb = xs[i]%ys[i];
        if (q_out[i]!=qb || r_out[i]!=rb) mism++;
    }

    double split_ms = (t1-t0)*1e3;
    double base_ms  = (t3-t2)*1e3;
    printf("J-LO hybrid N=%zu THRESH=%u  small=%zu big=%zu\n", N, THRESH, smallN, bigN);
    printf("Hybrid(simulated): %.2f ms  (%.2f Mops/s)\n", split_ms, (double)N/(t1-t0)/1e6);
    printf("CPU baseline:      %.2f ms  (%.2f Mops/s)\n", base_ms,  (double)N/(t3-t2)/1e6);
    printf("Mismatches: %zu\n", mism);

    free(xs); free(ys); free(xs_small); free(ys_small); free(idx_small);
    free(xs_big); free(ys_big); free(idx_big); free(q_out); free(r_out);
    return 0;
}
