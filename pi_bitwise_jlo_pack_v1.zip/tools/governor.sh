#!/usr/bin/env bash
# Optional: set CPU governor to performance (Pi 4/5), requires sudo
set -e
if [[ $EUID -ne 0 ]]; then
  echo "Please run as root: sudo $0"
  exit 1
fi
for cpu in /sys/devices/system/cpu/cpu[0-9]*; do
  echo performance > "$cpu/cpufreq/scaling_governor" || true
done
echo "Governor set to performance."
